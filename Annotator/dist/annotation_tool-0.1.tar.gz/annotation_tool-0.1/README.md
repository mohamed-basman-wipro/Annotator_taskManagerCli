# Annotation Tool
Tool to perform AST, Variable, Conditional, and Dynamic (RightTyper) annotations.
